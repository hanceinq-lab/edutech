import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { Plus, Users, DollarSign, BookOpen, Video } from 'lucide-react';

export default function InstructorDashboard() {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', category: '', level: 'beginner', price: '' });

  useEffect(() => {
    api.get('/courses?instructor=me').then(({ data }) => setCourses(data.courses));
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    const { data } = await api.post('/courses', form);
    setCourses((prev) => [data.course, ...prev]);
    setShowCreate(false);
    setForm({ title: '', description: '', category: '', level: 'beginner', price: '' });
  };

  const handlePublish = async (courseId, current) => {
    await api.put(`/courses/${courseId}`, { isPublished: !current });
    setCourses((prev) => prev.map((c) => c._id === courseId ? { ...c, isPublished: !current } : c));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Instructor Dashboard</h1>
          <p className="text-gray-500">Manage your courses and students</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 bg-brand-600 text-white px-4 py-2.5 rounded-xl font-medium hover:bg-brand-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New course
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
        {[
          { icon: BookOpen, label: 'Courses', value: courses.length, color: 'text-blue-600 bg-blue-50' },
          { icon: Users, label: 'Students', value: courses.reduce((a, c) => a + (c.enrolledCount || 0), 0), color: 'text-green-600 bg-green-50' },
          { icon: DollarSign, label: 'Revenue', value: '$0', color: 'text-purple-600 bg-purple-50' },
          { icon: Video, label: 'Published', value: courses.filter(c => c.isPublished).length, color: 'text-amber-600 bg-amber-50' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="bg-white rounded-2xl border border-gray-200 p-5">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="text-2xl font-bold">{value}</div>
            <div className="text-sm text-gray-500">{label}</div>
          </div>
        ))}
      </div>

      {/* Courses table */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {['Course', 'Students', 'Price', 'Status', 'Actions'].map(h => (
                <th key={h} className="px-4 py-3 text-left font-medium text-gray-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {courses.map((c) => (
              <tr key={c._id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-medium text-gray-900 max-w-xs truncate">{c.title}</td>
                <td className="px-4 py-3 text-gray-600">{c.enrolledCount || 0}</td>
                <td className="px-4 py-3 text-gray-600">{c.isFree ? 'Free' : `$${c.price}`}</td>
                <td className="px-4 py-3">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${c.isPublished ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                    {c.isPublished ? 'Published' : 'Draft'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => handlePublish(c._id, c.isPublished)}
                    className="text-brand-600 hover:underline text-xs font-medium"
                  >
                    {c.isPublished ? 'Unpublish' : 'Publish'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {courses.length === 0 && (
          <div className="text-center py-16 text-gray-400">No courses yet. Create your first one!</div>
        )}
      </div>

      {/* Create course modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg">
            <h2 className="text-xl font-semibold mb-4">Create new course</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              {[
                { name: 'title', label: 'Course title', type: 'text', placeholder: 'e.g. Complete React Course' },
                { name: 'category', label: 'Category', type: 'text', placeholder: 'e.g. Web Development' },
                { name: 'price', label: 'Price (0 for free)', type: 'number', placeholder: '29.99' },
              ].map(({ name, label, type, placeholder }) => (
                <div key={name}>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                  <input
                    type={type}
                    placeholder={placeholder}
                    value={form[name]}
                    onChange={(e) => setForm(p => ({ ...p, [name]: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 ring-brand-500"
                    required={name !== 'price'}
                  />
                </div>
              ))}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Level</label>
                <select
                  value={form.level}
                  onChange={(e) => setForm(p => ({ ...p, level: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 ring-brand-500"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))}
                  rows={3}
                  placeholder="What will students learn?"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 ring-brand-500 resize-none"
                  required
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowCreate(false)} className="flex-1 border border-gray-300 rounded-xl py-2.5 text-sm font-medium hover:bg-gray-50">
                  Cancel
                </button>
                <button type="submit" className="flex-1 bg-brand-600 text-white rounded-xl py-2.5 text-sm font-medium hover:bg-brand-700 transition-colors">
                  Create course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}